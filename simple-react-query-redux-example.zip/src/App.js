import React, { useEffect, useState } from "react";
import "./styles.css";
import { combineReducers } from "redux";
import { Provider, useDispatch, useSelector } from "react-redux";
import { createSlice, configureStore } from "@reduxjs/toolkit";
import { useQuery, QueryCache, ReactQueryCacheProvider } from "react-query";
import { ReactQueryDevtools } from "react-query-devtools";

/* Store */
const reposSlice = createSlice({
  name: "repos",
  initialState: { results: [], recentTerms: [] },
  reducers: {
    setRepos(state, action) {
      state.results = action.payload.response.items;
      if (!state.recentTerms.includes(action.payload.searchTerm)) {
        state.recentTerms.push(action.payload.searchTerm);
      }
    }
  }
});
export const { setRepos } = reposSlice.actions;

const rootReducer = combineReducers({ repos: reposSlice.reducer });
const store = configureStore({
  reducer: rootReducer
});

/**
 * API
 */
const cache = new QueryCache({
  defaultConfig: {
    queries: {
      cacheTime: 1000 * 60,
      staleTime: 1000 * 60
    }
  }
});

async function getRepositories(_key, searchTerm) {
  let params = new URLSearchParams();
  params.append("q", searchTerm);
  const endpoint = `https://api.github.com/search/repositories?${params.toString()}`;
  const result = await fetch(endpoint);
  const response = await result.json();
  return { searchTerm, response };
}

/* Components  */
function Sidebar(props) {
  const { recentTerms } = useSelector((store) => store.repos);
  return (
    <aside>
      <h3>Recent Searches</h3>
      {recentTerms.map((term) => (
        <button key={term} onClick={() => props.setSearchTerm(term)}>
          {term}
        </button>
      ))}
    </aside>
  );
}

function MainApp() {
  const { results } = useSelector((store) => store.repos);
  if (!results) return null;
  return (
    <div>
      <ol>
        {results.map((result) => (
          <li key={result.full_name}>
            <h2>{result.full_name}</h2>
          </li>
        ))}
      </ol>
    </div>
  );
}

function App() {
  const [searchTerm, setSearchTerm] = useState("");
  const dispatch = useDispatch();
  const { data, isLoading } = useQuery(
    ["search", searchTerm],
    getRepositories,
    {
      enabled: !!searchTerm
    }
  );
  useEffect(() => {
    if (data) {
      dispatch(setRepos(data));
    }
  }, [data, dispatch]);

  return (
    <div className="App">
      <h1>Search for a Github Repo</h1>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          setSearchTerm(document.querySelector(".search").value);
        }}
      >
        <input type="text" className="search" />
        <button type="submit">Submit</button>
      </form>
      {searchTerm ? <h2>Results for: {searchTerm}</h2> : null}
      <div className="grid">
        <Sidebar setSearchTerm={setSearchTerm} />
        {isLoading ? <div>Loading</div> : <MainApp />}
      </div>
      <ReactQueryDevtools />
    </div>
  );
}

export default function Index() {
  return (
    <ReactQueryCacheProvider queryCache={cache}>
      <Provider store={store}>
        <App />
      </Provider>
    </ReactQueryCacheProvider>
  );
}
